
<?php
/*---------------------------------=*/
require_once 'Sql/StartEnv.php';
/*----------------------------------*/

mys

?>


<div id="content">
</div>

<script type="text/javascript" src="js/prototype.js"></script>
<script type="text/javascript" src="js/comet.js"></script>


<?php
/*----------------------------------*/
require_once 'Sql/EndEnv.php';

/*----------------------------------*/

?>