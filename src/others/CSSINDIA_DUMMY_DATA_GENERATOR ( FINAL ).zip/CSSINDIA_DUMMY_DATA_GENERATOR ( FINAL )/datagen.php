<?php

mysql_connect('localhost','root','root') or die('Unable to connect');
mysql_select_db('css_testdata') or die('Unable to select database');


$start=$end=0;

if($_GET['start']&& $_GET['end']){
    $start=trim($_GET['start']);
    $end=trim($_GET['end']);
}
elseif($_SERVER['argv']){
    $vars=$_SERVER['argv'];
    $start=$vars[1];
    $end=$vars[2];
}

if(!empty($start) && !empty($end))
{
    echo "Data Generating -> STARTED";
    
    $empIds=array('APC','BS','DM','DNS','DS','GB','GG','LC','MS','ND',
                 'RA','RS','SB','SM','SMJ','SP','UD','ST');
    
    $schmIds=array('GS','AG','AH','MC','MF','SBA','SM','SB','VR','VH');
    
    $genders=array('M','F');
    
    $locations=array('RAMKRISHNAPALLY','AMTA','BAGHATI','JUJURSHA','GG','MADHABPUR',
                     'UNSANI','NADIA-UD','DEVOK','SANKARPUR','PATAPGAR','TETULIA','WEST NARAYANPUR',
                     'MAJHER PARA','DANGADIGHLA','PRATAP GARH','ND','MUNSHIR HAT','SADHANPUR',
                     'TUNTBAGAN','SUBHASH NAGAR','DEY  PARA','ALAMPUR','SMALL BUSINESS','BAROFINGA',
                     'PANPUR','ADHATA','KULKI','BAGBERIA','PANCHLA','BIJNA','KRISHNOPALLY','NILGANG',
                     'SAKARIDAHA','BAIDYAPUR','MALIMATI PARA','CHALTABARIA','NATAGAR','NIBADHUI',
                     'NALPUR','LC','MOHANPUR','PADMALOVPUR','DARIASUDHI');
    
    $years=array(2010,2011);
    $capAmounts=array(2000,3000,4000,5000);
    $recDiv=array(200,500,1000);
    $donationAmounts=array(10,20,40);
    $feeAmpounts=array(30,50);
    
    for($k=$start;$k<=$end;$k++)
    {
        /**
          *  START TRANSACTION 
          */
        mysql_query("START TRANSACTION") or die("Unable to start transaction");
        
        $result0=mysql_query("SELECT MAX(ID) AS ID FROM ref_mst_entity");
        $maxId=mysql_fetch_array($result0,MYSQL_NUM);
        $i=$maxId[0]+1;
        $capId=rand(0,3);
        $eid=rand(0,17);
        $sid=rand(0,9);
        $gid=rand(0,1);
        $lid=rand(0,43);
        $yid=rand(0,1);
        $y1=$years[$yid];
        
        $d1=rand(1,28);
    
        if($y1==2010){
            $m1=rand(1,12);
            if($m1<4)$y1=2011;
        }
        else $m1=4;
        
        $custId=$entId=$schmIds[$sid].$i;
        $schm=$schmIds[$sid];
        $entType='Customer';
        $qEntId='CUST'.$i;
        $addrId='ADDR'.$i;
        $address="This a test address for ".$i;
        $name='BENEFICIARY '.$i;
        $tsId='TS'.$i;
        $desc="Test description $i";
        $empId=$empIds[$eid];
        $loc=$locations[$lid];
        $age=rand(25,40);
        $sex=$genders[$gid];
        $date1=$y1.'-'.$m1.'-'.$d1;
        $accountStatus='OPEN';
        
        $bsdAmount=30;
        $bsdAmountRec=$totalDonation=$totalFees=0;
        
        /**
          *  BENEFICIARY ENTRY 
          */
        $sql_1="INSERT INTO ref_mst_entity( ENTITY_ID, ENTITY_TYPE, PARENT_ENTITY_ID,
        ENTITY_UNIQUE_ID, ENTITY_NAME, ENTITY_DESC, NAME, AGE, SEX, CUSTOMER_ID,
        CUSTOMER_ENTRY_DATE,SCHEME_ID,ADDRESS_ID,LOCATION_ID) VALUES ('$entId','$entType','$empId',
        '$qEntId','$name','$desc','$name',$age,'$sex','$custId','$date1','$schm','$addrId','$loc')";
    
        
        $sql_2="INSERT INTO ref_mst_address(ADDRESS_ID,ADDRESS,COUNTRY) VALUES
        ('$addrId','$address','INDIA')";
        
        mysql_query($sql_1) or die($sql_1);
        mysql_query($sql_2) or die($sql_2);
        
        $capAmount=$capAmounts[$capId];
        $recDivId=rand(0,2);
        $recDivAmount=$recDiv[$recDivId];
        $date2=null;
        $recps=$capAmount/$recDivAmount;
        
        /**
          *  CAPITAL PAID 
          */
        
        $tdInfo= getTdId();
        $tdtlId=$tdInfo['id'];
        $tdId=$tdInfo['tdId'];
        $sql_3="UPDATE ltr_trn_details
                SET TRAN_DETAILS_ID='$tdId' , TRAN_SUMMARY_ID='$tsId', SCHEME_ID='$schm', CUSTOMER_ID='$custId',
                EMPLOYEE_ID='$empId' , PAYMENT_AMOUNT=$capAmount , PAYMENT_TYPE='CAPITAL_PAID', VOUCHER_NO='$custId' ,
                TRANSACTION_DATE='$date1', CUSTOM_COMMENT1='$name' , CUSTOM_COMMENT2='$sex'
                WHERE ID=$tdtlId";
        mysql_query($sql_3)or die($sql_3);
        $totalDtls=1;
        
        
        /**
          *  BSD RECEIPT 
          */
        $tdInfo= getTdId();
        $tdtlId=$tdInfo['id'];
        $tdId=$tdInfo['tdId'];
        $bsdMemo='BMEMO'.$tdtlId;
        $sql_4="UPDATE ltr_trn_details
                SET TRAN_DETAILS_ID='$tdId' , TRAN_SUMMARY_ID='$tsId', SCHEME_ID='$schm', CUSTOMER_ID='$custId',
                EMPLOYEE_ID='$empId' , RECEIPT_AMOUNT=$bsdAmount, RECEIPT_TYPE='BSD_RECEIVED', MEMO_NO='$bsdMemo' ,
                TRANSACTION_DATE='$date1'
                WHERE ID=$tdtlId";
        mysql_query($sql_4) or die($sql_4);
        $totalDtls++;
                
        $amount=0;
        $l=rand(1,$recps);
        
        /**
          *  CAPITAL RECEIPT 
          */
        for($j=1;$j<=$l;$j++){
            $amount+=$recDivAmount;    
            $tdInfo= getTdId();
            $tdtlId=$tdInfo['id'];
            $tdId=$tdInfo['tdId'];
            $memo='RMEMO'.$tdtlId;
            
            $sql_5="UPDATE ltr_trn_details
                    SET TRAN_DETAILS_ID='$tdId', TRAN_SUMMARY_ID='$tsId', SCHEME_ID='$schm', CUSTOMER_ID='$custId',
                    EMPLOYEE_ID='$empId' , RECEIPT_AMOUNT=$recDivAmount , RECEIPT_TYPE='CAPITAL_RECEIVED', MEMO_NO='$memo' ,
                    TRANSACTION_DATE='$date1'
                    WHERE ID=$tdtlId";
            mysql_query($sql_5) or die($sql_5);
            
            /**
              *   DONATION ENTRY
              */
            if($i%2==0 && rand(0,1)==1)
            {
                $tdInfo= getTdId();
                $tdtlId=$tdInfo['id'];
                $tdId=$tdInfo['tdId'];
                $memo='DMEMO'.$tdtlId;
                $dAmount=$donationAmounts[rand(0,2)];
                
                $sql_8="UPDATE ltr_trn_details
                        SET TRAN_DETAILS_ID='$tdId', TRAN_SUMMARY_ID='$tsId', SCHEME_ID='$schm', CUSTOMER_ID='$custId',
                        EMPLOYEE_ID='$empId' , RECEIPT_AMOUNT=$dAmount , RECEIPT_TYPE='DONATION_RECEIVED', MEMO_NO='$memo' ,
                        TRANSACTION_DATE='$date1'
                        WHERE ID=$tdtlId";                        
                mysql_query($sql_8) or die($sql_8);
                $totalDonation+=$dAmount;
            }
            $totalDtls++;
        }
        
        /**
          *  FEES ENTRY 
          */
        if(rand(0,1)==1){
            $tdInfo= getTdId();
            $tdtlId=$tdInfo['id'];
            $tdId=$tdInfo['tdId'];
            $memo='FMEMO'.$tdtlId;
            $fAmount=$feeAmpounts[rand(0,1)];
            
            $sql_9="UPDATE ltr_trn_details
                    SET TRAN_DETAILS_ID='$tdId', TRAN_SUMMARY_ID='$tsId', SCHEME_ID='$schm', CUSTOMER_ID='$custId',
                    EMPLOYEE_ID='$empId' , RECEIPT_AMOUNT=$fAmount , RECEIPT_TYPE='PROCESSING_FEES', MEMO_NO='$memo' ,
                    TRANSACTION_DATE='$date1'
                    WHERE ID=$tdtlId";
            mysql_query($sql_9) or die($sql_9);
            $totalFees+=$fAmount;
        }
        
        $dueAmount=$capAmount-$amount;
        
        if($amount==$capAmount){
            $bsdAmountRec=$bsdAmount;
            $accountStatus='CLOSE';
            $sql_6="UPDATE ltr_trn_details
                SET TRAN_DETAILS_ID='$tdId' , TRAN_SUMMARY_ID='$tsId', SCHEME_ID='$schm', CUSTOMER_ID='$custId',
                EMPLOYEE_ID='$empId' , PAYMENT_AMOUNT=$bsdAmountRec , PAYMENT_TYPE='BSD_PAID', VOUCHER_NO='$custId' ,
                TRANSACTION_DATE='$date1', CUSTOM_COMMENT1='$name' , CUSTOM_COMMENT2='$sex'
                WHERE ID=$tdtlId";
             mysql_query($sql_6)or die($sql_6);
        }
        
        /**
          *  PAYAMENT INFORMATION 
          */
        $sql_7="INSERT INTO ltr_trn_summary (TRAN_SUMMARY_ID, SCHEME_ID, CUSTOMER_ID, EMPLOYEE_ID, TOTAL_PAYMENT_PRINCIPAL,
        TOTAL_RECEIPT_PRINCIPAL, TOTAL_RECEIPT_DUE_PRINCIPAL, TOTAL_RECEIPT_DONATION, TOTAL_RECEIPT_FEES, TOTAL_PAYMENT_SECURITY_DEPOSITE,
        TOTAL_RECEIPT_SECURITY_DEPOSITE,ACTIVE_STATUS,START_DATE,LATEST_DATE,TOTAL_DETAILS) VALUES ('$tsId','$schm','$custId','$empId',
        $capAmount, $amount, $dueAmount, $totalDonation, $totalFees, $bsdAmount, $bsdAmountRec, '$accountStatus', '$date1', '$date1', $totalDtls)";        
        mysql_query($sql_7) or die($sql_7);
        
        /**
         * COMMIT TRANSACTION
        */
        mysql_query("COMMIT") or die('Unable to save transaction');
    }
    
    echo "\nData Generating -> ENDED";
    
}

function getTdId(){
        
        $sql_1 = "INSERT INTO  ltr_trn_details SET  TRAN_DETAILS_ID=null";
        $result3=mysql_query($sql_1) or die('Unable to getTdId 1 ');
        
        $sql_2 = "SELECT MAX(ID)  FROM ltr_trn_details";
        $result4=mysql_query($sql_2 )or die('Unable to getTdId 2 ');;
        
        $maxId=mysql_fetch_array($result4,MYSQL_NUM);
        $result['tdId']='TD'.$maxId[0];
        $result['id']=$maxId[0];
            
        return $result;
    }

?>