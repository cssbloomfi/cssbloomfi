
<2010-07-05 03:07:44 BST> Database connected successfully
<2010-07-05 13:07:51 BST> Database connected successfully
<2010-07-05 18:07:55 BST> Database connected successfully