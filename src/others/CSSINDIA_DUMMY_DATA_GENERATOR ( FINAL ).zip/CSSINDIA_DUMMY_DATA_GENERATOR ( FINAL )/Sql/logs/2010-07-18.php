
<2010-07-18 17:07:21 BST> Database connected successfully