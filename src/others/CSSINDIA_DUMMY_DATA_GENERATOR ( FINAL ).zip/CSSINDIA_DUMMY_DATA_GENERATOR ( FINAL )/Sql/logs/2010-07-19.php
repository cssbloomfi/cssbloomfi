
<2010-07-19 04:07:32 BST> Database connected successfully
<2010-07-19 04:07:40 BST> Database connected successfully