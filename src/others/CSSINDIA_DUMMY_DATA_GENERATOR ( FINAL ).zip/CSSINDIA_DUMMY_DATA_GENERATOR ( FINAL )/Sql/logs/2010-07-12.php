
<2010-07-12 04:07:05 BST> Database connected successfully