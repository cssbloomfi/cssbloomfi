
<2011-04-26 03:04:28 BST> Database connected successfully
<2011-04-26 03:04:29 BST> Database connected successfully
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> Database connected successfully
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> Database connected successfully
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> Database connected successfully
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> Database connected successfully
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> Database connected successfully
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> Database connected successfully
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> Database connected successfully
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> Database connected successfully
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> Database connected successfully
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> Database connected successfully
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> Database connected successfully
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> Database connected successfully
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> Database connected successfully
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> Database connected successfully
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> Database connected successfully
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> Database connected successfully
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> Database connected successfully
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> Database connected successfully
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> Database connected successfully
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> Database connected successfully
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> Database connected successfully
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> Database connected successfully
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> Database connected successfully
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> Database connected successfully
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> Database connected successfully
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> Database connected successfully
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> Database connected successfully
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> Database connected successfully
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> Database connected successfully
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> Database connected successfully
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> Database connected successfully
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> Database connected successfully
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> Database connected successfully
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> Database connected successfully
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> Database connected successfully
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> Database connected successfully
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> Database connected successfully
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> Database connected successfully
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> Database connected successfully
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> Database connected successfully
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> Database connected successfully
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> Database connected successfully
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> Database connected successfully
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> Database connected successfully
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> Database connected successfully
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> Database connected successfully
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> Database connected successfully
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> Database connected successfully
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> Database connected successfully
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> Database connected successfully
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> Database connected successfully
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> Database connected successfully
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> Database connected successfully
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> Database connected successfully
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> Database connected successfully
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> Database connected successfully
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> Database connected successfully
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> Database connected successfully
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> Database connected successfully
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> Database connected successfully
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> Database connected successfully
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> Database connected successfully
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> Database connected successfully
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> Database connected successfully
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> Database connected successfully
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> Database connected successfully
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> Database connected successfully
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> Database connected successfully
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> Database connected successfully
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> Database connected successfully
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> Database connected successfully
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> Database connected successfully
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> Database connected successfully
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> Database connected successfully
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> Database connected successfully
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> Database connected successfully
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> Database connected successfully
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> Database connected successfully
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> Database connected successfully
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> Database connected successfully
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> Database connected successfully
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> Database connected successfully
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> Database connected successfully
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> Database connected successfully
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> Database connected successfully
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> Database connected successfully
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> Database connected successfully
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> Database connected successfully
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> Database connected successfully
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> Database connected successfully
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> Database connected successfully
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> Database connected successfully
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> Database connected successfully
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> Database connected successfully
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> Database connected successfully
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> Database connected successfully
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> Database connected successfully
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> Database connected successfully
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> Database connected successfully
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> Database connected successfully
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> Database connected successfully
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> Database connected successfully
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> Database connected successfully
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> Database connected successfully
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> Database connected successfully
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> Database connected successfully
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> Database connected successfully
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> Database connected successfully
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> Database connected successfully
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> Database connected successfully
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> Database connected successfully
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> Database connected successfully
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> Database connected successfully
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> Database connected successfully
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> Database connected successfully
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> Database connected successfully
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> Database connected successfully
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> Database connected successfully
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> Database connected successfully
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> Database connected successfully
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> Database connected successfully
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> Database connected successfully
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> Database connected successfully
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> Database connected successfully
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> Database connected successfully
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> Database connected successfully
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> Database connected successfully
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> Database connected successfully
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> Database connected successfully
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> Database connected successfully
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> Database connected successfully
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> Database connected successfully
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> Database connected successfully
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> Database connected successfully
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> Database connected successfully
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> Database connected successfully
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> Database connected successfully
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> Database connected successfully
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> Database connected successfully
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> Database connected successfully
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> Database connected successfully
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> Database connected successfully
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> Database connected successfully
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> Database connected successfully
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> Database connected successfully
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> Database connected successfully
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> Database connected successfully
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> Database connected successfully
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> Database connected successfully
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> Database connected successfully
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> Database connected successfully
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> Database connected successfully
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> Database connected successfully
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> Database connected successfully
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> Database connected successfully
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> Database connected successfully
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> Database connected successfully
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> Database connected successfully
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> Database connected successfully
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> Database connected successfully
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> Database connected successfully
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> Database connected successfully
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> Database connected successfully
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> Database connected successfully
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> Database connected successfully
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> Database connected successfully
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> Database connected successfully
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> Database connected successfully
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> Database connected successfully
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> Database connected successfully
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> Database connected successfully
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> Database connected successfully
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> Database connected successfully
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> Database connected successfully
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> Database connected successfully
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> Database connected successfully
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> Database connected successfully
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> Database connected successfully
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> Database connected successfully
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> Database connected successfully
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> Database connected successfully
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> Database connected successfully
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> Database connected successfully
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> Database connected successfully
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> Database connected successfully
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> Database connected successfully
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> Database connected successfully
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> Database connected successfully
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> Database connected successfully
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> Database connected successfully
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> Database connected successfully
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> Database connected successfully
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> Database connected successfully
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> Database connected successfully
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> Database connected successfully
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> Database connected successfully
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> Database connected successfully
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> Database connected successfully
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> Database connected successfully
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> Database connected successfully
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> Database connected successfully
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> Database connected successfully
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> Database connected successfully
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> Database connected successfully
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> Database connected successfully
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> Database connected successfully
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> Database connected successfully
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> Database connected successfully
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> Database connected successfully
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> Database connected successfully
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> Database connected successfully
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> Database connected successfully
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> Database connected successfully
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> Database connected successfully
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> Database connected successfully
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> Database connected successfully
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> Database connected successfully
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> Database connected successfully
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> Database connected successfully
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> Database connected successfully
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> Database connected successfully
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> Database connected successfully
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> Database connected successfully
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> Database connected successfully
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> Database connected successfully
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> Database connected successfully
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> Database connected successfully
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> Database connected successfully
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> Database connected successfully
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> Database connected successfully
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> Database connected successfully
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> Database connected successfully
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> Database connected successfully
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> Database connected successfully
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> Database connected successfully
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> Database connected successfully
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:00 BST> Database connected successfully
<2011-04-26 03:04:00 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:00 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:00 BST> Database connected successfully
<2011-04-26 03:04:00 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:00 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:00 BST> Database connected successfully
<2011-04-26 03:04:00 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:00 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:00 BST> Database connected successfully
<2011-04-26 03:04:00 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:00 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:00 BST> Database connected successfully
<2011-04-26 03:04:00 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:00 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:00 BST> Database connected successfully
<2011-04-26 03:04:00 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:00 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:00 BST> Database connected successfully
<2011-04-26 03:04:00 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:00 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:01 BST> Database connected successfully
<2011-04-26 03:04:01 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:01 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:01 BST> Database connected successfully
<2011-04-26 03:04:01 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:01 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:01 BST> Database connected successfully
<2011-04-26 03:04:01 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:01 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:01 BST> Database connected successfully
<2011-04-26 03:04:01 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:01 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:01 BST> Database connected successfully
<2011-04-26 03:04:01 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:01 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:01 BST> Database connected successfully
<2011-04-26 03:04:01 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> Database connected successfully
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> Database connected successfully
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> Database connected successfully
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> Database connected successfully
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> Database connected successfully
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> Database connected successfully
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> Database connected successfully
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> Database connected successfully
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> Database connected successfully
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> Database connected successfully
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> Database connected successfully
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> Database connected successfully
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> Database connected successfully
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> Database connected successfully
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> Database connected successfully
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> Database connected successfully
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> Database connected successfully
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> Database connected successfully
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> Database connected successfully
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> Database connected successfully
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:05 BST> Database connected successfully
<2011-04-26 03:04:05 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:05 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:05 BST> Database connected successfully
<2011-04-26 03:04:05 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:05 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:05 BST> Database connected successfully
<2011-04-26 03:04:05 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:05 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:05 BST> Database connected successfully
<2011-04-26 03:04:05 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:05 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:05 BST> Database connected successfully
<2011-04-26 03:04:05 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:05 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:05 BST> Database connected successfully
<2011-04-26 03:04:05 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:05 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> Database connected successfully
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> Database connected successfully
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> Database connected successfully
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> Database connected successfully
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> Database connected successfully
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> Database connected successfully
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> Database connected successfully
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> Database connected successfully
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> Database connected successfully
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> Database connected successfully
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> Database connected successfully
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> Database connected successfully
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> Database connected successfully
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> Database connected successfully
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:08 BST> Database connected successfully
<2011-04-26 03:04:08 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:08 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:08 BST> Database connected successfully
<2011-04-26 03:04:08 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:08 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:08 BST> Database connected successfully
<2011-04-26 03:04:08 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:08 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:08 BST> Database connected successfully
<2011-04-26 03:04:08 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:08 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:08 BST> Database connected successfully
<2011-04-26 03:04:08 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:08 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> Database connected successfully
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> Database connected successfully
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> Database connected successfully
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> Database connected successfully
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> Database connected successfully
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> Database connected successfully
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:10 BST> Database connected successfully
<2011-04-26 03:04:10 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:10 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:10 BST> Database connected successfully
<2011-04-26 03:04:10 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:10 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:10 BST> Database connected successfully
<2011-04-26 03:04:10 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:10 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:10 BST> Database connected successfully
<2011-04-26 03:04:10 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:10 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:10 BST> Database connected successfully
<2011-04-26 03:04:10 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:10 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> Database connected successfully
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> Database connected successfully
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> Database connected successfully
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> Database connected successfully
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> Database connected successfully
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:12 BST> Database connected successfully
<2011-04-26 03:04:12 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:12 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:12 BST> Database connected successfully
<2011-04-26 03:04:12 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:12 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:12 BST> Database connected successfully
<2011-04-26 03:04:12 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:12 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:13 BST> Database connected successfully
<2011-04-26 03:04:13 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:13 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:13 BST> Database connected successfully
<2011-04-26 03:04:13 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:13 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:13 BST> Database connected successfully
<2011-04-26 03:04:13 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:13 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:13 BST> Database connected successfully
<2011-04-26 03:04:13 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:13 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:14 BST> Database connected successfully
<2011-04-26 03:04:14 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:14 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:14 BST> Database connected successfully
<2011-04-26 03:04:14 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:14 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:14 BST> Database connected successfully
<2011-04-26 03:04:14 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:14 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:15 BST> Database connected successfully
<2011-04-26 03:04:15 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:15 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:15 BST> Database connected successfully
<2011-04-26 03:04:15 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:15 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:15 BST> Database connected successfully
<2011-04-26 03:04:15 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:15 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:15 BST> Database connected successfully
<2011-04-26 03:04:15 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:15 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:15 BST> Database connected successfully
<2011-04-26 03:04:15 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:15 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> Database connected successfully
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> Database connected successfully
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> Database connected successfully
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> Database connected successfully
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> Database connected successfully
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> Database connected successfully
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:17 BST> Database connected successfully
<2011-04-26 03:04:17 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:17 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:17 BST> Database connected successfully
<2011-04-26 03:04:17 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:17 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:17 BST> Database connected successfully
<2011-04-26 03:04:17 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:17 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> Database connected successfully
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> Database connected successfully
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> Database connected successfully
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> Database connected successfully
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> Database connected successfully
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> Database connected successfully
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> Database connected successfully
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> Database connected successfully
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> Database connected successfully
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> Database connected successfully
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> Database connected successfully
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:20 BST> Database connected successfully
<2011-04-26 03:04:20 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:20 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:20 BST> Database connected successfully
<2011-04-26 03:04:20 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:20 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:20 BST> Database connected successfully
<2011-04-26 03:04:20 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:20 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:20 BST> Database connected successfully
<2011-04-26 03:04:20 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:20 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:20 BST> Database connected successfully
<2011-04-26 03:04:20 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:20 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:21 BST> Database connected successfully
<2011-04-26 03:04:21 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:21 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:21 BST> Database connected successfully
<2011-04-26 03:04:21 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:21 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:21 BST> Database connected successfully
<2011-04-26 03:04:21 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:21 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:21 BST> Database connected successfully
<2011-04-26 03:04:21 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:21 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:21 BST> Database connected successfully
<2011-04-26 03:04:21 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:21 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:21 BST> Database connected successfully
<2011-04-26 03:04:21 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:21 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:22 BST> Database connected successfully
<2011-04-26 03:04:22 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:22 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:22 BST> Database connected successfully
<2011-04-26 03:04:22 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:22 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:22 BST> Database connected successfully
<2011-04-26 03:04:22 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:22 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:22 BST> Database connected successfully
<2011-04-26 03:04:22 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:22 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:23 BST> Database connected successfully
<2011-04-26 03:04:23 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:23 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:23 BST> Database connected successfully
<2011-04-26 03:04:23 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:23 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:23 BST> Database connected successfully
<2011-04-26 03:04:23 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:23 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:24 BST> Database connected successfully
<2011-04-26 03:04:24 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:24 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:24 BST> Database connected successfully
<2011-04-26 03:04:24 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:24 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:24 BST> Database connected successfully
<2011-04-26 03:04:24 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:24 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:24 BST> Database connected successfully
<2011-04-26 03:04:24 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:24 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:24 BST> Database connected successfully
<2011-04-26 03:04:24 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:24 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> Database connected successfully
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> Database connected successfully
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> Database connected successfully
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> Database connected successfully
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> Database connected successfully
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> Database connected successfully
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:26 BST> Database connected successfully
<2011-04-26 03:04:26 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:26 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:26 BST> Database connected successfully
<2011-04-26 03:04:26 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:26 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:26 BST> Database connected successfully
<2011-04-26 03:04:26 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:26 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:26 BST> Database connected successfully
<2011-04-26 03:04:26 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:26 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:27 BST> Database connected successfully
<2011-04-26 03:04:27 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:27 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:27 BST> Database connected successfully
<2011-04-26 03:04:27 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:27 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:27 BST> Database connected successfully
<2011-04-26 03:04:27 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:27 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:27 BST> Database connected successfully
<2011-04-26 03:04:27 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:27 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:27 BST> Database connected successfully
<2011-04-26 03:04:27 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:27 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> Database connected successfully
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> Database connected successfully
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> Database connected successfully
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> Database connected successfully
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> Database connected successfully
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> Database connected successfully
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:29 BST> Database connected successfully
<2011-04-26 03:04:29 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:29 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:29 BST> Database connected successfully
<2011-04-26 03:04:29 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:29 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:29 BST> Database connected successfully
<2011-04-26 03:04:29 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:29 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> Database connected successfully
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> Database connected successfully
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> Database connected successfully
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> Database connected successfully
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> Database connected successfully
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> Database connected successfully
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> Database connected successfully
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> Database connected successfully
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> Database connected successfully
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> Database connected successfully
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> Database connected successfully
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> Database connected successfully
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> Database connected successfully
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> Database connected successfully
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> Database connected successfully
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> Database connected successfully
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> Database connected successfully
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> Database connected successfully
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> Database connected successfully
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> Database connected successfully
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> Database connected successfully
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> Database connected successfully
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> Database connected successfully
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> Database connected successfully
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> Database connected successfully
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> Database connected successfully
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> Database connected successfully
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> Database connected successfully
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> Database connected successfully
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> Database connected successfully
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> Database connected successfully
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> Database connected successfully
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> Database connected successfully
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> Database connected successfully
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> Database connected successfully
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> Database connected successfully
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> Database connected successfully
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> Database connected successfully
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> Database connected successfully
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> Database connected successfully
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> Database connected successfully
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> Database connected successfully
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> Database connected successfully
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> Database connected successfully
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> Database connected successfully
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> Database connected successfully
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> Database connected successfully
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> Database connected successfully
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> Database connected successfully
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> Database connected successfully
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> Database connected successfully
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> Database connected successfully
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> Database connected successfully
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> Database connected successfully
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> Database connected successfully
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> Database connected successfully
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> Database connected successfully
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> Database connected successfully
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> Database connected successfully
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> Database connected successfully
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> Database connected successfully
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> Database connected successfully
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> Database connected successfully
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> Database connected successfully
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> Database connected successfully
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> Database connected successfully
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> Database connected successfully
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> Database connected successfully
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> Database connected successfully
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> Database connected successfully
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> Database connected successfully
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> Database connected successfully
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> Database connected successfully
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> Database connected successfully
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> Database connected successfully
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> Database connected successfully
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> Database connected successfully
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> Database connected successfully
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> Database connected successfully
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> Database connected successfully
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> Database connected successfully
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> Database connected successfully
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> Database connected successfully
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> Database connected successfully
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> Database connected successfully
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> Database connected successfully
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> Database connected successfully
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> Database connected successfully
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> Database connected successfully
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> Database connected successfully
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> Database connected successfully
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> Database connected successfully
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> Database connected successfully
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> Database connected successfully
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> Database connected successfully
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> Database connected successfully
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> Database connected successfully
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> Database connected successfully
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> Database connected successfully
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> Database connected successfully
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> Database connected successfully
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> Database connected successfully
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> Database connected successfully
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> Database connected successfully
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> Database connected successfully
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> Database connected successfully
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> Database connected successfully
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> Database connected successfully
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> Database connected successfully
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> Database connected successfully
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> Database connected successfully
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> Database connected successfully
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> Database connected successfully
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> Database connected successfully
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> Database connected successfully
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> Database connected successfully
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> Database connected successfully
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> Database connected successfully
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> Database connected successfully
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> Database connected successfully
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> Database connected successfully
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> Database connected successfully
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> Database connected successfully
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> Database connected successfully
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:00 BST> Database connected successfully
<2011-04-26 03:04:00 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:00 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:00 BST> Database connected successfully
<2011-04-26 03:04:00 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:00 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:01 BST> Database connected successfully
<2011-04-26 03:04:01 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:01 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:01 BST> Database connected successfully
<2011-04-26 03:04:01 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:01 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:01 BST> Database connected successfully
<2011-04-26 03:04:01 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:01 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> Database connected successfully
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> Database connected successfully
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> Database connected successfully
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> Database connected successfully
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> Database connected successfully
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> Database connected successfully
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> Database connected successfully
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> Database connected successfully
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> Database connected successfully
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> Database connected successfully
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> Database connected successfully
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> Database connected successfully
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:05 BST> Database connected successfully
<2011-04-26 03:04:05 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:05 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:05 BST> Database connected successfully
<2011-04-26 03:04:05 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:05 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> Database connected successfully
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> Database connected successfully
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> Database connected successfully
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> Database connected successfully
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> Database connected successfully
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> Database connected successfully
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:08 BST> Database connected successfully
<2011-04-26 03:04:08 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:08 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:08 BST> Database connected successfully
<2011-04-26 03:04:08 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:08 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:08 BST> Database connected successfully
<2011-04-26 03:04:08 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:08 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:08 BST> Database connected successfully
<2011-04-26 03:04:08 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:08 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> Database connected successfully
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> Database connected successfully
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> Database connected successfully
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> Database connected successfully
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:10 BST> Database connected successfully
<2011-04-26 03:04:10 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:10 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:10 BST> Database connected successfully
<2011-04-26 03:04:10 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:10 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:10 BST> Database connected successfully
<2011-04-26 03:04:10 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:10 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> Database connected successfully
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> Database connected successfully
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> Database connected successfully
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> Database connected successfully
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:12 BST> Database connected successfully
<2011-04-26 03:04:12 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:12 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:12 BST> Database connected successfully
<2011-04-26 03:04:12 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:12 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:13 BST> Database connected successfully
<2011-04-26 03:04:13 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:13 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:13 BST> Database connected successfully
<2011-04-26 03:04:13 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:13 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:13 BST> Database connected successfully
<2011-04-26 03:04:13 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:13 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:14 BST> Database connected successfully
<2011-04-26 03:04:14 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:14 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:14 BST> Database connected successfully
<2011-04-26 03:04:14 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:14 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:14 BST> Database connected successfully
<2011-04-26 03:04:14 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:14 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:15 BST> Database connected successfully
<2011-04-26 03:04:15 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:15 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:15 BST> Database connected successfully
<2011-04-26 03:04:15 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:15 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:15 BST> Database connected successfully
<2011-04-26 03:04:15 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:15 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> Database connected successfully
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> Database connected successfully
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> Database connected successfully
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> Database connected successfully
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:17 BST> Database connected successfully
<2011-04-26 03:04:17 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:17 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:17 BST> Database connected successfully
<2011-04-26 03:04:17 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:17 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> Database connected successfully
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> Database connected successfully
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> Database connected successfully
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> Database connected successfully
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> Database connected successfully
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> Database connected successfully
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> Database connected successfully
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:20 BST> Database connected successfully
<2011-04-26 03:04:20 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:20 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:20 BST> Database connected successfully
<2011-04-26 03:04:20 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:20 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:20 BST> Database connected successfully
<2011-04-26 03:04:20 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:20 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:21 BST> Database connected successfully
<2011-04-26 03:04:21 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:21 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:21 BST> Database connected successfully
<2011-04-26 03:04:21 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:21 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:21 BST> Database connected successfully
<2011-04-26 03:04:21 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:21 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:22 BST> Database connected successfully
<2011-04-26 03:04:22 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:22 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:22 BST> Database connected successfully
<2011-04-26 03:04:22 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:22 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:22 BST> Database connected successfully
<2011-04-26 03:04:22 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:22 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:22 BST> Database connected successfully
<2011-04-26 03:04:22 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:22 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:22 BST> Database connected successfully
<2011-04-26 03:04:22 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:22 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:23 BST> Database connected successfully
<2011-04-26 03:04:23 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:23 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:23 BST> Database connected successfully
<2011-04-26 03:04:23 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:23 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:23 BST> Database connected successfully
<2011-04-26 03:04:23 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:23 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:24 BST> Database connected successfully
<2011-04-26 03:04:24 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:24 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:24 BST> Database connected successfully
<2011-04-26 03:04:24 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:24 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:24 BST> Database connected successfully
<2011-04-26 03:04:24 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:24 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> Database connected successfully
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> Database connected successfully
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> Database connected successfully
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:26 BST> Database connected successfully
<2011-04-26 03:04:26 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:26 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:26 BST> Database connected successfully
<2011-04-26 03:04:26 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:26 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:26 BST> Database connected successfully
<2011-04-26 03:04:26 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:26 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:27 BST> Database connected successfully
<2011-04-26 03:04:27 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:27 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:27 BST> Database connected successfully
<2011-04-26 03:04:27 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:27 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:27 BST> Database connected successfully
<2011-04-26 03:04:27 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:27 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> Database connected successfully
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> Database connected successfully
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> Database connected successfully
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:29 BST> Database connected successfully
<2011-04-26 03:04:29 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:29 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:29 BST> Database connected successfully
<2011-04-26 03:04:29 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:29 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:29 BST> Database connected successfully
<2011-04-26 03:04:29 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:29 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:29 BST> Database connected successfully
<2011-04-26 03:04:29 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:29 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> Database connected successfully
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> Database connected successfully
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> Database connected successfully
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> Database connected successfully
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> Database connected successfully
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> Database connected successfully
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> Database connected successfully
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> Database connected successfully
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> Database connected successfully
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> Database connected successfully
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> Database connected successfully
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> Database connected successfully
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> Database connected successfully
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> Database connected successfully
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> Database connected successfully
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> Database connected successfully
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> Database connected successfully
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> Database connected successfully
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> Database connected successfully
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> Database connected successfully
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> Database connected successfully
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> Database connected successfully
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> Database connected successfully
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> Database connected successfully
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> Database connected successfully
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> Database connected successfully
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> Database connected successfully
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> Database connected successfully
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> Database connected successfully
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> Database connected successfully
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> Database connected successfully
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> Database connected successfully
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> Database connected successfully
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> Database connected successfully
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> Database connected successfully
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> Database connected successfully
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> Database connected successfully
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> Database connected successfully
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> Database connected successfully
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> Database connected successfully
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> Database connected successfully
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> Database connected successfully
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> Database connected successfully
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> Database connected successfully
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> Database connected successfully
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> Database connected successfully
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> Database connected successfully
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> Database connected successfully
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> Database connected successfully
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> Database connected successfully
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> Database connected successfully
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> Database connected successfully
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> Database connected successfully
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> Database connected successfully
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> Database connected successfully
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> Database connected successfully
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> Database connected successfully
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> Database connected successfully
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> Database connected successfully
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> Database connected successfully
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> Database connected successfully
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> Database connected successfully
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> Database connected successfully
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> Database connected successfully
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> Database connected successfully
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> Database connected successfully
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> Database connected successfully
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> Database connected successfully
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> Database connected successfully
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:55 BST> Database connected successfully
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> Database connected successfully
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> Database connected successfully
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> Database connected successfully
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:56 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> Database connected successfully
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> Database connected successfully
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> Database connected successfully
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:57 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> Database connected successfully
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> Database connected successfully
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> Database connected successfully
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> Database connected successfully
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:58 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> Database connected successfully
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> Database connected successfully
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> Database connected successfully
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:59 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:00 BST> Database connected successfully
<2011-04-26 03:04:00 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:00 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:00 BST> Database connected successfully
<2011-04-26 03:04:00 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:00 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:01 BST> Database connected successfully
<2011-04-26 03:04:01 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:01 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:01 BST> Database connected successfully
<2011-04-26 03:04:01 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:01 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:01 BST> Database connected successfully
<2011-04-26 03:04:01 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:01 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> Database connected successfully
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> Database connected successfully
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:02 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> Database connected successfully
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> Database connected successfully
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> Database connected successfully
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> Database connected successfully
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:03 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> Database connected successfully
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> Database connected successfully
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> Database connected successfully
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:04 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:05 BST> Database connected successfully
<2011-04-26 03:04:05 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:05 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:05 BST> Database connected successfully
<2011-04-26 03:04:05 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:05 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:05 BST> Database connected successfully
<2011-04-26 03:04:05 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:05 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> Database connected successfully
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> Database connected successfully
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> Database connected successfully
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> Database connected successfully
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:06 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> Database connected successfully
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> Database connected successfully
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> Database connected successfully
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:07 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:08 BST> Database connected successfully
<2011-04-26 03:04:08 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:08 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:08 BST> Database connected successfully
<2011-04-26 03:04:08 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:08 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> Database connected successfully
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> Database connected successfully
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> Database connected successfully
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:09 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:10 BST> Database connected successfully
<2011-04-26 03:04:10 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:10 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:10 BST> Database connected successfully
<2011-04-26 03:04:10 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:10 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> Database connected successfully
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> Database connected successfully
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> Database connected successfully
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:11 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:12 BST> Database connected successfully
<2011-04-26 03:04:12 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:12 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:12 BST> Database connected successfully
<2011-04-26 03:04:12 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:12 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:13 BST> Database connected successfully
<2011-04-26 03:04:13 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:13 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:13 BST> Database connected successfully
<2011-04-26 03:04:13 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:13 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:14 BST> Database connected successfully
<2011-04-26 03:04:14 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:14 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:14 BST> Database connected successfully
<2011-04-26 03:04:14 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:14 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:14 BST> Database connected successfully
<2011-04-26 03:04:14 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:14 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:15 BST> Database connected successfully
<2011-04-26 03:04:15 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:15 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:15 BST> Database connected successfully
<2011-04-26 03:04:15 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:15 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:15 BST> Database connected successfully
<2011-04-26 03:04:15 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:15 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> Database connected successfully
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> Database connected successfully
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> Database connected successfully
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:16 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:17 BST> Database connected successfully
<2011-04-26 03:04:17 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:17 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:17 BST> Database connected successfully
<2011-04-26 03:04:17 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:17 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:17 BST> Database connected successfully
<2011-04-26 03:04:17 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:17 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:17 BST> Database connected successfully
<2011-04-26 03:04:17 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:17 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> Database connected successfully
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> Database connected successfully
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> Database connected successfully
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:18 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> Database connected successfully
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> Database connected successfully
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> Database connected successfully
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:19 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:20 BST> Database connected successfully
<2011-04-26 03:04:20 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:20 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:20 BST> Database connected successfully
<2011-04-26 03:04:20 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:20 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:21 BST> Database connected successfully
<2011-04-26 03:04:21 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:21 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:21 BST> Database connected successfully
<2011-04-26 03:04:21 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:21 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:22 BST> Database connected successfully
<2011-04-26 03:04:22 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:22 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:22 BST> Database connected successfully
<2011-04-26 03:04:22 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:22 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:23 BST> Database connected successfully
<2011-04-26 03:04:23 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:23 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:23 BST> Database connected successfully
<2011-04-26 03:04:23 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:23 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:24 BST> Database connected successfully
<2011-04-26 03:04:24 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:24 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:24 BST> Database connected successfully
<2011-04-26 03:04:24 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:24 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:24 BST> Database connected successfully
<2011-04-26 03:04:24 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:24 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> Database connected successfully
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> Database connected successfully
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> Database connected successfully
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> Database connected successfully
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:25 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:26 BST> Database connected successfully
<2011-04-26 03:04:26 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:26 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:27 BST> Database connected successfully
<2011-04-26 03:04:27 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:27 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:27 BST> Database connected successfully
<2011-04-26 03:04:27 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:27 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> Database connected successfully
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> Database connected successfully
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> Database connected successfully
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:28 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:29 BST> Database connected successfully
<2011-04-26 03:04:29 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:29 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:29 BST> Database connected successfully
<2011-04-26 03:04:29 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:29 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:29 BST> Database connected successfully
<2011-04-26 03:04:29 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:29 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> Database connected successfully
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> Database connected successfully
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> Database connected successfully
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> Database connected successfully
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:30 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> Database connected successfully
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> Database connected successfully
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> Database connected successfully
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:31 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> Database connected successfully
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> Database connected successfully
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:32 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> Database connected successfully
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> Database connected successfully
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> Database connected successfully
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:33 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> Database connected successfully
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> Database connected successfully
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> Database connected successfully
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:34 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> Database connected successfully
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> Database connected successfully
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:35 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> Database connected successfully
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:36 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> Database connected successfully
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> Database connected successfully
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> Database connected successfully
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:37 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> Database connected successfully
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> Database connected successfully
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> Database connected successfully
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> Database connected successfully
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:38 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> Database connected successfully
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> Database connected successfully
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> Database connected successfully
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:39 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> Database connected successfully
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> Database connected successfully
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> Database connected successfully
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:40 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> Database connected successfully
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> Database connected successfully
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:41 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> Database connected successfully
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> Database connected successfully
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:42 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> Database connected successfully
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> Database connected successfully
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> Database connected successfully
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:43 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> Database connected successfully
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> Database connected successfully
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:44 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> Database connected successfully
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> Database connected successfully
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:45 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> Database connected successfully
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:46 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> Database connected successfully
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> Database connected successfully
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:47 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> Database connected successfully
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> Database connected successfully
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:48 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> Database connected successfully
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> Database connected successfully
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:49 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> Database connected successfully
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> Database connected successfully
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:50 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> Database connected successfully
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> Database connected successfully
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:51 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> Database connected successfully
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> Database connected successfully
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:52 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> Database connected successfully
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:53 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> Database connected successfully
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 
<2011-04-26 03:04:54 BST> [Function - Defalt Name][SQL executed successfully] \nSELECT COUNT(CUSTOMER_ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' AND STATUS='NORMAL' AND CUSTOMER_ID IS NOT NULL 