<?php
require_once 'Sql/library/connectDb.php';
$sql=new connectSql;

defined('ROOT') || define('ROOT', realpath(dirname(dirname(__FILE__))));
//echo "path : ".ROOT;