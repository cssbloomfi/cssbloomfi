<?php
unset($sql);