<?php

class query
{
	public function defaultQuery()
	{
		
	}

}
