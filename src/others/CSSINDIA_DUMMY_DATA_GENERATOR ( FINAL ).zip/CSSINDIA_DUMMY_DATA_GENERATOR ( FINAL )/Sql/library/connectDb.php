<?php
/*
Name		: connectSQL
Actions		: to connect database and to run sql query
Date		: 22.1.2010
Created By	: Smritiman Barua
*/
class connectSQL
{
	public $host=null; 
	public $user=null;
	public $pass=null;
	public $db=null;
	public $log_config=null;
	public $connect_config=null;
	public $handle=null;
	public $info=null;

	function __construct()
	{
		$this->log_config=$this->getDbInfo("dblogconfig");
		$this->connect_config=$this->getDbInfo("dbconnect");
		if($this->log_config==1) {
			$this->handle = @fopen("Sql/logs/" . date("Y-m-d") . ".php", 'a', true);
			if (!$this->handle) throw new Exception('Failed to open stream'); }
		if($this->connect_config==1) {
			$this->connectDb();
			if($this->log_config==1) 
				$this->writeLog("Database connected successfully"); }
	}

	public function connectDb()
	{
		if(!$this->host)$host=$this->getDbInfo("dbhost");
		else $host=$this->host;
		if(!$this->user)$user=$this->getDbInfo("dbuser");
		else $user=$this->user;
		if(!$this->pass)$pass=$this->getDbInfo("dbpass");
		else $pass=$this->pass;
		if(!$this->db)$db=$this->getDbInfo("dbname");
		else $db=$this->db;
		
		if(!$host) echo "<br><b>Localhost</b> not found. Please  configuare '<b>dbhost</b>' in default configuration file <b>dbConfig.ini</b>";
		if(!$user) echo "<br><b>User Name</b> not found. Please configuare '<b>dbuser</b>' in default configuration file <b>dbConfig.ini</b>";
		if(!$pass) echo "<br><b>Password</b> not found. Please configuare '<b>dbpass</b>' in default configuration file <b>dbConfig.ini</b>";
		if(!$db) echo "<br><b>Database Name</b> not found. Please configuare '<b>dbname</b>' in default configuration file <b>dbConfig.ini</b>";
		if($host && $user && $pass && $db) {
		mysql_connect($host,$user,$pass) or die("<br>Unable to connect. Where Params [ HOST:$host  USER:$user PASSWORD:$pass ]");
		mysql_select_db($db) or die("<br>Unable to select database [ DATABASE:$db ]"); }
		else die("<br>Please check Host, User, Password and Database.");
	}

	public function setConnection($host,$user,$pass)
	{
		$this->host=$host;
		$this->user=$user;
		$this->pass=$pass;
	}

	public function setDb($db)
	{
		$this->db=$db;
	}

	public function runSql($sql,$name='Defalt Name',$dieMsg="<br>Unable To execute the SQL")
	{
		$result=mysql_query($sql) or die($dieMsg);
		if($this->log_config==1) $this->writeLog('[Function - '.$name.'][SQL executed successfully] \n'.$sql);
		return $result;
	}

	public function fetchObject($data=null)
	{
		if(!$data) echo "<br>Given data is empty";
		return mysql_fetch_object($data);
	}

	public function getDbInfo($key) 
	{
		$filename='Sql/dbConfig/dbConfig.ini';
		$f = fopen($filename, 'r');
		while ($line = fscanf($f, "%[^\=]=%[^\=]\n")) {
        list($k, $v) = $line;
        if ($k == $key) { fclose($f); return trim($v);}}
		fclose($f);
		return false;
	}

	public function writeLog($data)
	{
		fwrite($this->handle, "\n<".date("Y-m-d H:m:s T")."> ".$data);
	}
}
?>