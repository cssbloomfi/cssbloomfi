<?php

$startpath='Sql/StartEnv.php';
/*---------------------------------=*/
require_once ($startpath);
/*----------------------------------*/

$query="SELECT COUNT(ID) AS COUNT_NO FROM ref_mst_entity WHERE ENTITY_TYPE='Customer' ";

$result=$sql->runSql($query);
$row=$sql->fetchObject($result)->COUNT_NO;
// infinite loop until the data file is not modified
$initial_record_count=$row;

$result=$sql->runSql($query);
$row=$sql->fetchObject($result)->COUNT_NO;
$current_record_count=$row;

$query1="SELECT COUNT(ID) AS COUNT_NO FROM ltr_trn_details ";

$result1=$sql->runSql($query1);
$row1=$sql->fetchObject($result1)->COUNT_NO;
// infinite loop until the data file is not modified
$initial_record_count1=$row;

$result1=$sql->runSql($query1);
$row1=$sql->fetchObject($result1)->COUNT_NO;
$current_record_count1=$row1;

while ($initial_record_count <> $initial_record_count) // check if the record count change
{
  usleep(10000); // sleep 10ms to unload the CPU
  clearstatcache();
  $result=$sql->runSql($query);
  $row=$sql->fetchObject($result)->COUNT_NO;
  $current_record_count=$row;
  
  $result1=$sql->runSql($query1);
  $row1=$sql->fetchObject($result1)->COUNT_NO;
  $current_record_count1=$row1;
}

/*----------------------------------*/
require_once ('Sql/EndEnv.php');
/*----------------------------------*/

// return a json array
$response = array();
$response['schematabinfo'] = 'ref_mst_entity';
$response['schematabinfo1'] = 'ltr_trn_details';
$response['msg']       = $current_record_count;
$response['msg1']       = $current_record_count1;
$response['timestamp'] = $currentmodif;
echo json_encode($response);
flush();

?>